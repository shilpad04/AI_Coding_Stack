# Product Requirements Document: NBFC Digital Lending & Loan Management Platform

## 1. Project Overview

### 1.1 Project Name
**Saarthi LMS** — a Digital Lending and Loan Management Platform for a Non-Banking Financial Company (NBFC).

### 1.2 Product Summary
Saarthi LMS is an end-to-end digital lending platform for an NBFC that originates, underwrites, disburses, services, and collects unsecured and secured retail loans (personal loans, business loans, gold loans, and two-wheeler loans) directly and through a co-lending arrangement with partner banks. The system consists of a React/TypeScript customer-facing web and mobile-web application, an Angular-based internal Loan Origination System (LOS) and Loan Management System (LMS) console for loan officers, underwriters, and collections agents, and a FastAPI (Python) backend that houses the credit decisioning engine, loan lifecycle state machine, repayment ledger, and regulatory reporting jobs. PostgreSQL is the system of record; a message queue drives asynchronous jobs such as credit bureau pulls, NACH mandate registration, and NPA batch classification.

### 1.3 Business Context
- **Core Value:** Cuts loan turnaround time (TAT) from days to minutes for small-ticket retail loans by automating KYC, credit bureau pulls, and rule-based underwriting, while keeping a human-in-the-loop for exceptions and high-ticket approvals.
- **Regulatory Reality:** An NBFC in India operates under RBI's Scale-Based Regulation (SBR) framework, the Fair Practices Code, the Master Direction on KYC, and (for digital-first NBFCs) the RBI Digital Lending Guidelines, 2022. The system must be built with these as first-class constraints, not retrofitted later.
- **Key Differentiator:** A single platform that supports both direct-book lending and a Co-Lending Model (CLM) with partner banks under the RBI co-lending circular, with per-loan investor-share tracking from day one.

### 1.4 Glossary
- **NBFC:** Non-Banking Financial Company, an RBI-regulated lender that is not a bank.
- **LOS:** Loan Origination System — everything from lead to disbursement.
- **LMS:** Loan Management System — everything from disbursement to closure (servicing, collections, NPA).
- **KYC / CKYC:** Know Your Customer / Central KYC Registry.
- **CIC:** Credit Information Company (e.g. CIBIL, Experian, Equifax, CRIF High Mark).
- **IRAC norms:** Income Recognition and Asset Classification norms that define when a loan becomes an NPA.
- **NPA:** Non-Performing Asset — a loan overdue beyond the regulatory threshold.
- **DPD:** Days Past Due.
- **e-NACH:** Electronic National Automated Clearing House mandate, used for auto-debit of EMIs.
- **CLM:** Co-Lending Model — joint lending arrangement between an NBFC and a bank under a pre-agreed split.
- **FOIR:** Fixed Obligation to Income Ratio, used in underwriting.
- **AA:** Account Aggregator, the RBI-regulated framework for consented financial data sharing.

---

## 2. Problem Statement

### 2.1 User Problem
- Retail borrowers, especially thin-file and new-to-credit customers, face slow, paperwork-heavy loan processes at traditional lenders and often cannot get a decision same-day.
- Existing borrowers have no self-service way to check their outstanding balance, download a repayment schedule, or foreclose a loan without calling a branch.
- Small business borrowers need working-capital loans disbursed within 48 hours, which manual underwriting cannot reliably deliver.

### 2.2 Business Problem
- The NBFC's current process is spreadsheet- and email-driven, with no single system of record for loan state, leading to reconciliation errors between the collections team, finance, and the co-lending partner bank.
- Manual NPA classification is error-prone and has caused at least one delayed regulatory return in the past cycle.
- There is no systematic fraud or AML screening at onboarding, which is a growing regulatory and credit-loss risk.

### 2.3 Success Metrics
- Reduce average loan TAT (application to disbursement) from 3 business days to under 30 minutes for auto-approved personal loans.
- 100% of loans correctly classified into IRAC buckets (Standard, Special Mention Account, Sub-Standard, Doubtful, Loss) on every daily batch run.
- Zero manual reconciliation breaks between the NBFC's books and the co-lending partner bank's books at month-end.
- Reduce first-month default rate on new-to-credit personal loans by 15% via the new credit scoring model, measured against the prior manual-underwriting cohort.
- 90% of eligible borrowers complete KYC and e-sign entirely digitally, with no branch visit.

---

## 3. Scope

### 3.1 In Scope
- **Architecture:**
  - **Customer Frontend:** React + TypeScript (loan application, e-KYC, e-sign, self-service repayment dashboard).
  - **Internal Console:** Angular (LOS/LMS for loan officers, underwriters, collections agents, compliance/risk officers, finance/ops).
  - **Backend:** FastAPI / Python 3.12 (credit decisioning engine, loan lifecycle state machine, repayment ledger, NPA batch jobs, regulatory reporting).
  - **Database:** PostgreSQL (system of record), with a read replica for reporting.
  - **Async processing:** a message queue for credit bureau pulls, NACH mandate registration/status polling, SMS/WhatsApp notifications, and nightly NPA classification.
- **Loan Products:**
  - Unsecured Personal Loan (₹25,000 – ₹5,00,000, tenure 6–36 months).
  - Unsecured Business Loan / Working Capital Loan (₹1,00,000 – ₹25,00,000, tenure 6–48 months).
  - Secured Gold Loan (loan-to-value capped per RBI gold loan guidelines, tenure up to 12 months, bullet or EMI repayment).
  - Secured Two-Wheeler Loan (hypothecated to the vehicle, tenure 12–48 months).
- **Lending Models:**
  - Direct on-book lending (100% NBFC balance sheet).
  - Co-Lending Model (CLM) with a partner bank, per the RBI co-lending circular, at a configurable split (default 80:20 bank:NBFC for priority-sector-eligible loans).
- **Core Modules:**
  - Digital onboarding & KYC (Aadhaar e-KYC / DigiLocker / CKYC search, PAN verification, liveness + face-match).
  - Credit bureau integration and rule-based + ML credit scoring.
  - Loan origination workflow with configurable approval matrices.
  - e-Sign loan agreement and Key Fact Statement (KFS) generation, per RBI Digital Lending Guidelines.
  - Disbursement (direct bank transfer, with co-lending split at source where applicable).
  - Repayment: e-NACH auto-debit, manual UPI/card payment, prepayment, and foreclosure.
  - Collections: bucket-wise queues, agent allocation, promise-to-pay tracking, and a collections call/field dialer integration.
  - IRAC-based NPA classification, provisioning computation, and restructuring workflow.
  - Regulatory reporting: RBI returns (e.g. DNBS/NBS returns), CIC data upload, and internal MIS dashboards.
  - Fraud and AML screening at onboarding and at disbursement (PEP/sanctions list screening, velocity checks, duplicate-identity checks).
  - Grievance redressal per the Fair Practices Code, with defined SLA escalation.

### 3.2 Out of Scope
- Deposit-taking, savings accounts, or any liability product (this NBFC is a non-deposit-taking NBFC-ND-SI; deposit products are explicitly disallowed by its RBI category).
- Insurance underwriting or bancassurance issuance (insurance cross-sell links out to a third-party partner; this platform does not underwrite insurance).
- Core banking replacement for the co-lending partner bank — the platform integrates with, but does not replace, the partner bank's own core banking system.
- Cryptocurrency, virtual digital asset lending, or peer-to-peer lending — none of these are supported loan types.
- A physical branch point-of-sale / teller cash-handling system — all disbursement and repayment is digital/bank-transfer based.

### 3.3 Assumptions
- The NBFC already holds a valid Certificate of Registration from the RBI and is classified as an NBFC-ND-SI (Non-Deposit-taking, Systemically Important) or NBFC-MFI as applicable per product.
- The NBFC has an existing agreement in place (or will execute one during Phase 5) with at least one Credit Information Company and at least one co-lending partner bank.
- The backend runs behind the organization's existing API gateway and VPC; this PRD does not cover network/infra provisioning.
- All borrower-facing communication is in English and at least one regional language, to be finalized with the compliance team before Phase 1 UI freeze.

---

## 4. Users and Roles

### 4.1 Primary Users
- **Borrowers** — individuals and small business owners applying for and repaying loans.
- **Loan Officers** — front-line staff who assist walk-in or referred applicants and review flagged applications.
- **Credit Underwriters** — review system-flagged applications that fail auto-approval rules, and approve/reject/counter-offer.
- **Collections Agents** — work overdue-loan queues, log promise-to-pay commitments, and escalate to the field/legal team.
- **Compliance & Risk Officers** — monitor fraud/AML alerts, sign off on regulatory returns, and manage the grievance redressal queue.
- **Finance & Accounts** — reconcile disbursements and collections against the co-lending partner bank, and generate provisioning entries.
- **Co-Lending Partner Bank (external, API-integrated)** — receives loan-level data feeds and disbursement/collection settlement files.
- **System Administrator** — manages user roles, approval-matrix configuration, and product parameter configuration.

### 4.2 Roles and Permissions
| Role | Can View | Can Approve | Can Configure |
|---|---|---|---|
| Borrower | Own loan(s) only | Own e-sign consent only | Own KYC documents, own notification preferences |
| Loan Officer | Applications in their assigned queue | Nothing (recommends only) | Nothing |
| Credit Underwriter | All applications routed to underwriting | Loans within their delegated sanction limit | Nothing |
| Senior Underwriter / Credit Committee | All applications | Loans above a Credit Underwriter's limit, up to the Credit Committee's limit | Approval-matrix thresholds (with Admin sign-off) |
| Collections Agent | Loans in their assigned bucket/queue | Promise-to-pay entries; cannot waive principal | Nothing |
| Collections Manager | All collections queues | Settlement/waiver requests up to a configured cap | Bucket-to-agent allocation rules |
| Compliance & Risk Officer | All loans, all alerts, all regulatory reports | Grievance resolution; fraud-alert disposition | AML rule thresholds |
| Finance & Accounts | All disbursement/settlement/provisioning records | Reconciliation sign-off | Chart of accounts mapping |
| System Administrator | Everything (audit-logged) | Nothing loan-specific | User roles, product parameters, approval matrix |

---

## 5. Functional Requirements

### 5.1 Customer Onboarding & KYC

1. The system shall let a prospective borrower start an application by entering mobile number and receiving an OTP for verification.
2. The system shall perform Aadhaar-based e-KYC (via UIDAI-authorized channel) or DigiLocker-based document pull, and shall additionally support manual document upload with a loan officer's assisted verification as a fallback.
3. The system shall query the Central KYC Registry (CKYC) for an existing KYC record before initiating fresh e-KYC, to avoid duplicate KYC and to prefill available demographic data.
4. The system shall verify PAN against the Income Tax Department's PAN verification API and shall block onboarding if the PAN is invalid or does not match the applicant's name within a configurable fuzzy-match threshold.
5. The system shall perform a liveness check and face-match between the applicant's selfie and their KYC document photograph, and shall flag a mismatch below a configurable confidence score for manual review rather than auto-rejecting.
6. The system shall capture and store consent artifacts (timestamp, IP address, consent text version) for every data-sharing consent obtained from the applicant, per the Digital Personal Data Protection Act and RBI Digital Lending Guidelines requirements on data consent.
7. The system shall support a "Digital Loan Application" record that persists partial progress, so an applicant who drops off can resume within a configurable expiry window (default 7 days) without re-entering completed steps.

### 5.2 Credit Bureau Integration & Credit Scoring

1. The system shall pull a credit report from at least one integrated Credit Information Company (CIBIL, Experian, Equifax, or CRIF High Mark) using the applicant's PAN and consent, and shall cache the report for the duration of that application per the CIC's data-reuse policy.
2. The system shall compute a FOIR (Fixed Obligation to Income Ratio) using self-declared or bank-statement-derived income and existing EMI obligations pulled from the bureau report, and shall reject applications exceeding a configurable FOIR threshold (default 50%).
3. The system shall run a rule-based pre-qualification check (minimum bureau score, no active NPA/write-off in bureau history, minimum vintage of credit history) before invoking the ML credit scoring model, to avoid wasting a model call on clearly ineligible applicants.
4. The system shall invoke the ML credit scoring model (see Section 6.1) for applicants who pass pre-qualification, and shall record the model's score, score version, and top contributing factors against the application for audit purposes.
5. The system shall classify each scored application into Auto-Approve, Auto-Reject, or Refer-to-Underwriter, based on configurable score bands that can be tuned per loan product without a code deployment.
6. The system shall support connecting a borrower's bank account via the Account Aggregator (AA) framework as an alternative or supplement to bureau data, for thin-file applicants with limited bureau history.

### 5.3 Loan Product Configuration

1. The system shall let an Administrator define a loan product with: product code, min/max ticket size, tenure range, interest rate (fixed or reducing-balance), processing fee structure, prepayment/foreclosure charge rules, and applicable approval matrix.
2. The system shall support product-level eligibility rules (e.g. minimum age, minimum income, employment type) that are evaluated before the credit bureau pull, to reject clearly ineligible applicants without incurring a bureau-pull cost.
3. The system shall version every product configuration change, and shall always evaluate an in-flight application against the product configuration version that was active when the application was created, not the latest version.

### 5.4 Loan Application & Origination

1. The system shall generate a unique application reference number at the start of every application and shall track the application through a defined state machine: `DRAFT -> KYC_PENDING -> KYC_COMPLETE -> BUREAU_PULLED -> SCORED -> UNDERWRITING -> APPROVED -> AGREEMENT_PENDING -> AGREEMENT_SIGNED -> DISBURSEMENT_PENDING -> DISBURSED -> REJECTED -> WITHDRAWN`.
2. The system shall not allow an application to skip a state in the machine; every transition shall be logged with timestamp, actor (system or user ID), and reason.
3. The system shall allow a Loan Officer to submit an application on behalf of a walk-in applicant, with the same KYC and eligibility checks as a self-service application.
4. The system shall generate the loan offer (approved amount, tenure, interest rate, EMI amount, processing fee, and a full repayment schedule) immediately upon approval, for the applicant's review before e-sign.
5. The system shall let an Underwriter counter-offer a different amount or tenure than requested, and shall require fresh applicant acceptance of the counter-offer before proceeding to agreement generation.

### 5.5 Underwriting & Approval Workflow

1. The system shall route an application flagged "Refer-to-Underwriter" to the underwriting queue based on the assigned Loan Officer's branch/region, or to a central pool queue if unassigned.
2. The system shall enforce a configurable delegation-of-authority (approval) matrix: a Credit Underwriter can approve up to their sanction limit; anything above routes to a Senior Underwriter or Credit Committee.
3. The system shall require a documented reason (free text, minimum length enforced) for every manual rejection or counter-offer, for audit and Fair Practices Code compliance.
4. The system shall allow an Underwriter to request additional documents from the applicant without rejecting the application, pausing the SLA clock while awaiting the applicant's response.
5. The system shall enforce a maximum underwriting SLA (configurable per product, default 24 hours for personal loans) and shall auto-escalate an application that breaches SLA to the Collections/Underwriting Manager.

### 5.6 Loan Agreement & e-Sign

1. The system shall generate a Key Fact Statement (KFS) in the RBI-prescribed format, showing the Annual Percentage Rate (APR), all fees, and the full repayment schedule, and shall require the applicant to view the KFS before proceeding to e-sign, per the RBI Digital Lending Guidelines, 2022.
2. The system shall generate the loan agreement document from a versioned template, populated with applicant and loan-specific data, and shall route it for Aadhaar-based e-sign (via an authorized e-sign service provider).
3. The system shall store the e-signed agreement, the KFS, and the consent artifacts as immutable records, retrievable by the applicant from their self-service dashboard at any time during the loan's life and for the regulatory retention period after closure.
4. The system shall provide a mandatory "cooling-off"/look-up period after agreement e-sign (configurable, default per the Digital Lending Guidelines) during which the borrower may cancel the loan and repay only the principal disbursed plus proportionate interest, without a foreclosure penalty.

### 5.7 Disbursement

1. The system shall initiate disbursement only after the loan agreement is e-signed and the mandatory cooling-off period (if applicable to the flow) has been configured correctly for that product.
2. The system shall disburse via direct bank transfer (IMPS/NEFT/RTGS as amount-appropriate) to a bank account that has passed a penny-drop verification confirming the account holder's name matches the applicant's KYC name.
3. For a Co-Lending Model loan, the system shall split the disbursement instruction at source according to the configured bank:NBFC ratio for that product, generate separate disbursement records for each lender's book, and transmit the bank's share instruction to the partner bank's integration endpoint.
4. The system shall deduct the processing fee and any other pre-disbursement charges from the disbursed amount (or collect them upfront, per product configuration) and shall reflect the net disbursed amount accurately in the repayment schedule basis.
5. The system shall generate a disbursement confirmation, updated repayment schedule with the actual disbursement date, and a system-generated welcome communication (SMS/email/WhatsApp) to the borrower.

### 5.8 Repayment & EMI Management

1. The system shall register an e-NACH mandate on the borrower's bank account at or before first disbursement, and shall track mandate status (pending, active, rejected, revoked) with the sponsor bank/NPCI.
2. The system shall present each EMI for auto-debit on its due date via the active e-NACH mandate, and shall retry a failed auto-debit per a configurable retry schedule (e.g. day 0, day 3, day 7) before marking it as a missed EMI.
3. The system shall support manual repayment via UPI or card payment link, for borrowers without an active mandate or who wish to prepay.
4. The system shall support full foreclosure and partial prepayment, recomputing the outstanding principal, applicable foreclosure charges (per product configuration), and a revised repayment schedule (for partial prepayment) or account closure (for full foreclosure).
5. The system shall maintain a complete, immutable transaction ledger per loan account: every disbursement, EMI collection, charge, waiver, and adjustment, each with a timestamp, amount, and running balance.
6. The system shall generate and make available to the borrower, on demand, a loan statement / repayment schedule / interest certificate (for tax purposes) covering any date range within the loan's life.

### 5.9 Collections & Recovery

1. The system shall automatically move a loan account into a collections bucket based on DPD (Days Past Due): Bucket 0 (0 DPD, current), Bucket 1 (1–30 DPD), Bucket 2 (31–60 DPD), Bucket 3 (61–90 DPD), and NPA (90+ DPD, see Section 5.10).
2. The system shall allocate overdue accounts to Collections Agents based on configurable rules (bucket, geography, agent capacity), and shall support manual reallocation by a Collections Manager.
3. The system shall let a Collections Agent log a call disposition (e.g. Promise to Pay, Refused to Pay, Not Reachable, Disputed) and, for Promise to Pay, capture a committed payment date and amount.
4. The system shall automatically flag a broken Promise to Pay (committed date passed, no payment received) and surface it in the agent's and manager's dashboards for follow-up.
5. The system shall support a configurable settlement/waiver workflow, requiring Collections Manager (and, above a threshold, Compliance) approval before a settlement is applied to a loan account.
6. The system shall generate a legal-notice-ready case file (borrower details, loan documents, transaction history, communication log) for accounts that a Collections Manager marks for legal escalation.

### 5.10 NPA Classification & Provisioning (IRAC Norms)

1. The system shall run a nightly batch job that reclassifies every active loan account's asset classification per RBI IRAC norms based on DPD: Standard (current, or within permissible overdue), Special Mention Account (SMA-0/1/2 sub-buckets per configured DPD thresholds), Sub-Standard (typically 90–365 days as NPA), Doubtful, and Loss, with exact thresholds configurable to match the latest applicable RBI circular for the NBFC's category.
2. The system shall compute expected credit loss / provisioning for each account per its asset classification, using a configurable provisioning matrix (percentage by classification and product type), and shall aggregate this into a daily provisioning report for Finance.
3. The system shall prevent an account from moving back to Standard classification purely by a partial payment that does not clear the full overdue amount, per RBI's non-cherry-picking upgrade rules — an account can only be upgraded to Standard once all arrears (principal and interest) are cleared.
4. The system shall log every asset classification change with the batch run ID, prior classification, new classification, and computed DPD, and shall make this history queryable for audit and regulatory inspection purposes.
5. The system shall support a restructuring workflow (per applicable RBI restructuring framework) that, upon approval, revises the repayment schedule and correctly resets or preserves the asset classification per the specific restructuring scheme's rules — this must never silently reset a genuinely stressed account back to Standard.

### 5.11 Co-Lending / Partner Bank Integration

1. The system shall maintain, per Co-Lending Model loan, the exact split ratio, each lender's principal outstanding, each lender's share of every collection and every charge, computed consistently with the signed co-lending agreement's waterfall logic.
2. The system shall generate a daily/monthly settlement file in the partner bank's agreed format, reconciling disbursements and collections at the loan level, for automated or semi-automated reconciliation on both sides.
3. The system shall surface a reconciliation-break dashboard to Finance & Accounts, flagging any loan where the NBFC's books and the last-received partner-bank statement disagree beyond a configurable tolerance.
4. The system shall notify the partner bank's integration endpoint of every material loan lifecycle event (disbursement, NPA classification change, foreclosure, write-off) applicable per the co-lending agreement's reporting terms.

### 5.12 Regulatory Reporting

1. The system shall generate the periodic regulatory returns applicable to the NBFC's category (e.g. NBS returns, and any Scale-Based Regulation-tier-specific returns) in the RBI-prescribed format, sourced directly from the system of record rather than manual compilation.
2. The system shall generate a CIC upload file (credit bureau reporting format) on the applicable cycle (typically monthly/fortnightly), covering every active and closed loan account's current status, DPD, and outstanding balance.
3. The system shall maintain an audit trail sufficient for an RBI inspection: every loan's full lifecycle history, every underwriting decision with the underwriter's identity and rationale, and every asset classification change, retrievable without engineering intervention.
4. The system shall generate an internal MIS pack (portfolio at risk, vintage curves, product-wise delinquency, co-lending exposure) on a configurable schedule for management review.

### 5.13 Customer Servicing & Grievance Redressal

1. The system shall provide a borrower self-service dashboard showing current outstanding balance, next EMI due date and amount, full repayment schedule, transaction history, and downloadable statements/certificates.
2. The system shall let a borrower raise a service request or grievance (e.g. disputed charge, incorrect DPD, request for NOC after closure) through the self-service dashboard, and shall route it to the appropriate queue with a tracked ticket ID.
3. The system shall enforce the Fair Practices Code's grievance resolution SLA (e.g. an initial response within a configurable number of days, and a maximum resolution time before escalation to the Compliance Officer / a nominated Grievance Redressal Officer).
4. The system shall generate a No Objection Certificate (NOC) / loan closure letter automatically upon full and final settlement of a loan account, without requiring a manual document-generation step.

### 5.14 Fraud & AML Monitoring

1. The system shall screen every applicant, at onboarding, against Politically Exposed Persons (PEP) and applicable sanctions lists, and shall block disbursement (not just flag) on a confirmed match pending Compliance sign-off.
2. The system shall run duplicate-identity checks (same PAN/Aadhaar-hash/mobile number applying under different names, or the same device fingerprint used across many distinct applications within a short window) and shall flag suspected identity fraud for manual review before underwriting proceeds.
3. The system shall run velocity checks (e.g. more than N applications from the same device/IP within a configurable window) and route matches to the fraud queue rather than auto-approving.
4. The system shall maintain a suspicious-activity log queryable by the Compliance & Risk Officer, and shall support generating a Suspicious Transaction Report (STR)-ready case file for filings required under the Prevention of Money Laundering Act (PMLA) framework.

### 5.15 Gold Loan Specific Requirements

1. The system shall record, per pledged gold loan, the gross weight, net (stone-deducted) weight, purity (karat/fineness as appraised), and the appraised value computed against the applicable per-gram rate on the appraisal date, using a rate source and haircut consistent with RBI's gold loan LTV guidelines.
2. The system shall enforce the maximum permissible loan-to-value ratio against the appraised value at disbursement, and shall re-evaluate LTV on any top-up or renewal request rather than assuming the original appraisal remains valid indefinitely.
3. The system shall record the identity of the appraiser and the branch where the gold is held in safe custody, and shall log every custody transfer (e.g. inter-branch movement) with dual authorization.
4. The system shall track the loan's tenure and, on maturity without full repayment, shall move the account through a defined pre-auction notice workflow (borrower notification per the required notice period) before an auction can be initiated.
5. The system shall record auction proceeds against the loan account, apply them to outstanding principal, interest, and charges in the configured order of appropriation, and shall record any surplus payable back to the borrower or any shortfall to be pursued as an unsecured claim.
6. The system shall never allow an auction-initiation action without the pre-auction notice having been sent and its notice-period having elapsed, enforced in code, not only in process documentation.

### 5.16 DSA / Channel Partner Management

1. The system shall support onboarding a Direct Selling Agent (DSA) or channel partner as a distinct entity, with their own KYC/due-diligence record, empanelment status, and commission agreement terms.
2. The system shall let a DSA submit a loan application referencing their partner code, and shall track the source channel on every application for both commission computation and portfolio-quality monitoring by source.
3. The system shall compute DSA commission based on disbursed (not merely approved) loans, per the agreed commission structure (flat fee or percentage of disbursed amount, potentially tiered by product), and shall claw back a proportionate commission if the underlying loan is cancelled within the cooling-off period.
4. The system shall let Risk & Compliance monitor per-DSA portfolio quality (early-DPD rate, fraud-flag rate) and shall support suspending a DSA's ability to submit new applications pending review, without affecting their existing referred loans already in the book.

---

## 6. AI / Model Requirements

### 6.1 Credit Scoring Model
- **Purpose:** Predict probability of default within the first 12 months, to support the Auto-Approve / Auto-Reject / Refer-to-Underwriter decision in Section 5.2.
- **Inputs:** Bureau report features (score, trade line history, utilization, delinquency history), self-declared income and employment data, and (where consented) Account Aggregator bank-statement-derived features (average balance, salary credit regularity, existing EMI debits visible in statements).
- **Output:** A calibrated probability of default plus a small set of top contributing factors (for adverse-action explainability, since a rejected applicant is entitled to know the principal reason under the Fair Practices Code).
- **Model Governance:** Every score is recorded against the application with the model version that produced it. Score bands mapping to Auto-Approve/Auto-Reject/Refer are configuration, not code, so Risk can retune bands without a deployment. The model must be periodically revalidated (backtested against realized default outcomes) on a defined cadence, with the validation report retained for audit.
- **Fallback:** If the model service is unavailable or times out, the application shall route to Refer-to-Underwriter rather than fail open (auto-approve) or fail closed (auto-reject) — a model outage must never silently change credit policy.

### 6.2 Fraud Detection Model
- **Purpose:** Score each application for fraud likelihood (identity fraud, income fabrication, application-ring fraud) at onboarding, feeding the checks in Section 5.14.
- **Inputs:** Device fingerprint, application velocity features, document-tampering signals from the e-KYC vendor, and bureau-inquiry-velocity (many recent inquiries across lenders).
- **Output:** A fraud risk score and reason codes, routed to the fraud queue above a configurable threshold; this model never auto-rejects on its own — every high-score case requires a human fraud-queue review before rejection.

### 6.3 Collections Prioritization Model
- **Purpose:** Rank overdue accounts within a bucket by likelihood of cure with a well-timed contact, so Collections Agents work the highest-yield accounts first.
- **Inputs:** Payment history pattern, prior Promise-to-Pay reliability, DPD trend, and contact-channel response history.
- **Output:** A priority score feeding the agent's queue ordering (Section 5.9); this is an operational ranking aid, not a decisioning model — it must never itself trigger legal escalation or NPA classification, which remain rule-based per Section 5.10.

---

## 7. Data Requirements

### 7.1 Core Data Entities
- **Applicant / Borrower:** demographic data, KYC documents and verification status, consent records.
- **Application:** state, product, requested and approved terms, scoring results, underwriting decision trail.
- **Loan Account:** disbursed principal, interest rate, tenure, repayment schedule, current outstanding, asset classification, co-lending split.
- **Transaction Ledger:** every disbursement, collection, charge, waiver, and adjustment against a loan account, immutable and append-only.
- **Collections Case:** bucket, assigned agent, disposition history, Promise-to-Pay records, settlement/legal escalation status.
- **Document Store:** KYC documents, loan agreement, KFS, e-sign certificates, NOC — all versioned and retained per the regulatory retention schedule.
- **Audit Log:** every state transition and manual decision across all of the above, with actor, timestamp, and reason where applicable.

### 7.2 Data Retention & Residency
- All personally identifiable and financial data shall be stored on infrastructure located in India, per RBI data localization requirements applicable to payment and financial data.
- Loan records, KYC documents, and audit logs shall be retained for the minimum period prescribed by applicable RBI Master Directions after loan closure, and shall not be purged automatically before that period.
- Consent artifacts and communication logs shall be retained for at least the same period as the loan record they relate to.

### 7.3 Data Access Controls
- Access to unmasked PAN, Aadhaar-derived identifiers, and bank account numbers shall be role-restricted and fully audit-logged, including read access (not just writes).
- Borrower data shall never be exposed to the co-lending partner bank beyond what is contractually necessary for their share of the loan (i.e., the bank should not see the NBFC's other, non-co-lent, customers' data).

---

## 8. Integration Requirements

### 8.1 External Integrations
- **Credit Information Companies:** CIBIL, Experian, Equifax, and/or CRIF High Mark — bureau pull (Section 5.2) and periodic bureau reporting (Section 5.12).
- **e-KYC / Identity:** UIDAI-authorized Aadhaar e-KYC provider, DigiLocker, CKYC Registry, PAN verification (Income Tax Department API).
- **Account Aggregator:** an RBI-licensed AA for consented bank-statement data pulls (Section 5.2, Section 6.1).
- **Payment Rails:** e-NACH/NPCI mandate registration and presentation, UPI collection links, IMPS/NEFT/RTGS disbursement rails.
- **e-Sign:** an authorized e-sign service provider for Aadhaar-based document signing (Section 5.6).
- **Communication:** SMS gateway, email, and WhatsApp Business API for OTPs, notifications, and statements.
- **Co-Lending Partner Bank:** a settlement/reconciliation file exchange and a lifecycle-event webhook/API integration (Section 5.11).
- **Sanctions/PEP Screening Provider:** a third-party screening API for Section 5.14.

### 8.2 API Endpoints (FastAPI Backend — indicative, not exhaustive)
- `POST /api/applications` — create a new loan application.
- `POST /api/applications/{id}/kyc` — submit/trigger KYC verification.
- `POST /api/applications/{id}/bureau-pull` — trigger a credit bureau pull.
- `POST /api/applications/{id}/score` — invoke the credit scoring model.
- `POST /api/applications/{id}/decision` — record an underwriting decision.
- `POST /api/applications/{id}/agreement` — generate the loan agreement and KFS.
- `POST /api/applications/{id}/disburse` — trigger disbursement.
- `GET /api/loans/{id}` — retrieve full loan account state.
- `POST /api/loans/{id}/repayments` — record a manual repayment.
- `GET /api/loans/{id}/schedule` — retrieve the repayment schedule.
- `POST /api/collections/cases/{id}/disposition` — log a collections call disposition.
- `GET /api/reports/npa-classification` — retrieve the latest NPA classification batch output.
- `GET /api/reports/co-lending-settlement` — retrieve a co-lending settlement file for a given period.

---

## 9. Non-Functional & Compliance Requirements

### 9.1 Performance & Availability
- The credit decisioning pipeline (bureau pull through score through auto-decision) shall complete within 60 seconds for at least 95% of applications under normal load.
- The self-service borrower dashboard and repayment endpoints shall be available 99.5% of the time, excluding a pre-announced maintenance window.
- The nightly NPA classification batch shall complete within a fixed operational window (e.g. before 6 AM) so that same-day collections and reporting can rely on fresh classification.

### 9.2 Security
- All PII and financial data shall be encrypted at rest and in transit.
- The system shall enforce role-based access control per Section 4.2, with every privileged action (approval, waiver, classification override) captured in an immutable audit log.
- The system shall support multi-factor authentication for all internal console users (Loan Officer, Underwriter, Collections, Compliance, Admin).

### 9.3 Regulatory Compliance
- The platform shall be designed to comply with: the RBI Master Direction on KYC, the RBI Digital Lending Guidelines 2022 (including KFS, cooling-off period, and loan service provider disclosure norms), the RBI Fair Practices Code for NBFCs, applicable IRAC norms for asset classification, the RBI co-lending circular (for CLM loans), and the Digital Personal Data Protection Act for consent and data handling.
- Any change to a regulatory parameter (IRAC DPD thresholds, provisioning percentages, KFS format, cooling-off period length) shall be a configuration change reviewable by Compliance, not a hardcoded value requiring an engineering release.

### 9.4 Auditability
- Every automated decision (auto-approve, auto-reject, NPA classification) shall be explainable after the fact: which rule or model version fired, on what inputs, at what timestamp — sufficient to answer a regulator's or an ombudsman's query without engineering involvement.

### 9.5 Disaster Recovery & Business Continuity
- The system shall maintain a documented Recovery Point Objective (RPO) and Recovery Time Objective (RTO) for the loan ledger and repayment-schedule data, given that any data loss here is a direct financial and regulatory risk, not merely an availability inconvenience.
- The nightly NPA classification batch and the co-lending settlement job shall be individually re-runnable/idempotent, so a failed run can be safely retried without double-counting a classification change or a settlement entry.
- The system shall maintain a documented fallback procedure for each external dependency (bureau outage, e-sign provider outage, e-NACH rail outage) so that, at minimum, in-flight applications degrade to a manual/assisted path rather than silently stalling with no visibility to the applicant or the Loan Officer.

### 9.6 Accessibility & Localization
- The customer-facing application shall meet a documented accessibility standard (e.g. WCAG 2.1 AA) for screen-reader and keyboard-navigation support, given the borrower base includes users with limited digital literacy and, in some cases, visual impairment.
- The customer-facing application and all borrower communications (SMS, email, WhatsApp, KFS, agreement) shall be available in English and at least one regional language selected during onboarding, with the borrower able to change their language preference at any time from the self-service dashboard.
- Numeric and currency formatting shall follow the Indian numbering convention (lakh/crore grouping) throughout the customer-facing application and all generated statements.

---

## 10. Workflow / User Journeys

### 10.1 Personal Loan — Digital Journey (Auto-Approved Path)
1. Applicant enters mobile number, verifies OTP, and starts a new personal loan application.
2. Applicant completes Aadhaar e-KYC; system cross-checks against CKYC and verifies PAN.
3. Applicant declares income and employment details, and consents to a credit bureau pull.
4. System pulls the bureau report, computes FOIR, runs pre-qualification rules, then invokes the credit scoring model.
5. System auto-approves, generates the loan offer, KFS, and repayment schedule, and presents them to the applicant.
6. Applicant accepts the offer, e-signs the agreement via Aadhaar e-sign, and registers an e-NACH mandate.
7. Cooling-off period elapses (or applicant proceeds where not applicable); system disburses to the applicant's verified bank account.
8. Applicant receives a disbursement confirmation and can immediately view the loan in their self-service dashboard.

### 10.2 Business Loan — Refer-to-Underwriter Path
1. Applicant completes onboarding and KYC as in 10.1, but for a higher ticket size that exceeds the auto-approval band.
2. System pulls the bureau report and scores the application, classifying it Refer-to-Underwriter.
3. Application enters the underwriting queue; a Credit Underwriter reviews bureau data, declared financials, and may request additional documents (e.g. bank statements, GST returns).
4. Underwriter either approves within their delegated limit, escalates to the Credit Committee (if above their limit), issues a counter-offer, or rejects with a documented reason.
5. On approval or accepted counter-offer, the journey continues from KFS presentation (step 5 of 10.1) through disbursement.

### 10.3 Overdue Loan — Collections Journey
1. An EMI auto-debit fails; the system retries per the configured retry schedule and, if still unpaid, moves the account into Bucket 1 collections.
2. The account is allocated to a Collections Agent per the allocation rules; the agent contacts the borrower and logs a disposition.
3. If a Promise to Pay is logged and honored, the account returns to current status once all arrears clear (per Section 5.10's no-cherry-picking rule).
4. If the account continues to age past 90 DPD, the nightly NPA batch reclassifies it as Sub-Standard; Collections Manager and Compliance are notified.
5. If recovery efforts fail, the Collections Manager may initiate a settlement workflow (with required approvals) or escalate to legal, generating the legal case file.

### 10.4 Co-Lending Settlement Journey
1. A loan under the Co-Lending Model is disbursed with the split executed at source per Section 5.7.
2. Every subsequent collection against that loan is apportioned between the NBFC and the partner bank per the agreed waterfall.
3. On the agreed settlement cadence, the system generates a settlement file and Finance & Accounts reconciles it against the partner bank's statement, resolving any flagged breaks via the reconciliation dashboard.

---

## 11. Acceptance Criteria

- [ ] Tech stack uses **FastAPI** for the backend, **React/TypeScript** for the customer-facing app, and **Angular** for the internal LOS/LMS console, backed by **PostgreSQL**.
- [ ] Every loan application transitions strictly through the defined state machine (Section 5.4); no state is ever skipped, and every transition is logged.
- [ ] The credit scoring model's fallback behavior on outage routes to Refer-to-Underwriter, never to silent auto-approve or auto-reject.
- [ ] The nightly NPA classification batch correctly buckets every active loan by DPD per configured IRAC thresholds, and an account with partially-cleared arrears is never upgraded to Standard.
- [ ] Every co-lending loan's principal, collections, and charges are split and tracked per-lender consistently with the configured ratio, with no unreconciled break exceeding the configured tolerance at month-end.
- [ ] The Key Fact Statement is generated and shown to the applicant before e-sign on every loan, with no path that allows agreement e-sign without a prior KFS view.
- [ ] Every manual underwriting rejection or counter-offer requires and stores a documented reason.
- [ ] All PII and financial data is encrypted at rest and in transit, and every privileged action (approval, waiver, classification override, data access to unmasked identifiers) is captured in an immutable audit log.
- [ ] The fraud/AML screening blocks disbursement (not just flags) on a confirmed sanctions/PEP match pending Compliance sign-off.
- [ ] A borrower can, entirely self-service, view their outstanding balance, download a statement, and raise a grievance without contacting a branch.

---

## 12. Implementation Phases

### Phase 1: Foundations — Onboarding, KYC, and Product Configuration
- Set up the FastAPI backend project structure, PostgreSQL schema for applicants, applications, and product configuration.
- Implement mobile OTP verification, Aadhaar e-KYC / DigiLocker integration, CKYC lookup, and PAN verification.
- Implement liveness/face-match integration and consent artifact capture.
- Build the Admin console screens for loan product configuration and versioning.
- Write pytest unit tests for KYC state transitions, PAN/CKYC edge cases (mismatch, no record found), and product configuration versioning.

### Phase 2: Credit Decisioning — Bureau Integration and Scoring
- Integrate at least one Credit Information Company for bureau pulls; implement FOIR computation and pre-qualification rules.
- Stand up the credit scoring model service (Section 6.1) with score-band configuration and the Refer-to-Underwriter fallback behavior.
- Implement Account Aggregator integration as a supplementary data source for thin-file applicants.
- Write unit and integration tests covering auto-approve, auto-reject, refer, and model-outage-fallback paths.

### Phase 3: Origination — Application, Underwriting, Agreement, and Disbursement
- Implement the full application state machine (Section 5.4) and the underwriting queue/approval-matrix workflow (Section 5.5).
- Implement KFS generation, loan agreement templating, and e-sign integration, including the cooling-off period logic.
- Implement disbursement, including the co-lending split-at-source logic for CLM loans.
- Write end-to-end tests for the full personal-loan auto-approved journey and the business-loan refer-to-underwriter journey (Sections 10.1–10.2).

### Phase 4: Servicing — Repayment, Self-Service, and Collections
- Implement e-NACH mandate registration and EMI auto-debit presentation with retry logic.
- Build the borrower self-service dashboard (balance, schedule, statements, grievance raising).
- Implement the collections bucket engine, agent allocation, disposition logging, and Promise-to-Pay tracking.
- Write unit tests for the transaction ledger's immutability guarantees and for collections bucket transitions under various payment scenarios.

### Phase 5: Risk & Regulatory — NPA, Reporting, Fraud/AML, Co-Lending Settlement
- Implement the nightly IRAC-based NPA classification batch job and the provisioning computation.
- Implement regulatory return generation, CIC reporting file generation, and the co-lending settlement/reconciliation module.
- Implement fraud/AML screening (PEP/sanctions, duplicate-identity, velocity checks) and the Compliance fraud/grievance queues.
- Write unit tests for NPA classification edge cases (partial payment, restructuring, upgrade eligibility) and settlement reconciliation break detection.

### Phase 6: Hardening — Performance, Security, and Model Governance
- Load-test the credit decisioning pipeline and the nightly NPA batch against the performance targets in Section 9.1.
- Complete a security review (encryption at rest/in transit, RBAC audit, MFA enforcement) against Section 9.2.
- Establish the model revalidation cadence and documentation process for the credit scoring, fraud, and collections-prioritization models (Section 6).
- Conduct an internal mock regulatory-inspection dry run against the audit trail and reporting requirements in Sections 9.4 and 5.12.

---

## 13. Risks & Open Items

### 13.1 Known Risks
- **Regulatory drift:** RBI periodically revises IRAC thresholds, digital lending disclosure norms, and co-lending terms. Every regulatory parameter must stay configuration-driven (Section 9.3); a hardcoded threshold discovered during an audit is treated as a production incident, not a backlog item.
- **Bureau/e-KYC vendor outage:** the credit decisioning pipeline depends on at least one external CIC and one e-KYC provider being reachable. A single-vendor integration for either is a single point of failure for the entire origination funnel; Phase 2/1 should evaluate a second vendor as a fallback before General Availability.
- **Co-lending reconciliation drift:** if the partner bank's settlement file format changes without notice, the reconciliation-break dashboard (Section 5.11) could silently accumulate unresolved breaks. This needs an explicit alert (not just a dashboard) when the unreconciled count or value crosses a threshold.
- **Model/score-band mismatch after retuning:** if Risk retunes score bands (Section 6.1) without coordinating with Underwriting capacity, a large volume of applications could shift from Auto-Approve to Refer-to-Underwriter overnight, overwhelming the underwriting queue. A band change should trigger a capacity-planning check, not deploy silently.

### 13.2 Open Items for Stakeholder Sign-Off
- Final list of supported regional languages for Section 9.6 (Localization) — pending Compliance and Marketing input.
- Confirmation of which RBI SBR tier the NBFC currently falls under, since this determines which specific regulatory returns in Section 5.12 are mandatory versus not applicable.
- Final commission structure and clawback terms for the DSA channel (Section 5.16) — pending Business sign-off on the partner agreement template.
- Confirmation of the second CIC/e-KYC vendor (Section 13.1 risk) — pending a vendor evaluation and cost comparison.

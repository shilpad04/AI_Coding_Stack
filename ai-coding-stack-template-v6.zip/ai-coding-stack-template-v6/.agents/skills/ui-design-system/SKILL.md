---
name: ui-design-system
description: >-
  Modern UI design and styling skill. Enforces vibrant dark mode aesthetics,
  glassmorphism, clean typography, responsive layouts, and interactive micro-animations.
---

# UI Design System & Modern Aesthetics Skill

Use this skill when creating or modifying frontend components, pages, CSS styles, or user interfaces.

---

## 1. Visual Excellence & Aesthetics

Never output plain, generic, unstyled HTML. Build interfaces that feel state-of-the-art and production-ready:

- **Harmonious Dark Theme**: Use deep slate/zinc backgrounds (`#0B0F19`, `#111827`) with glowing accents (`#6366F1`, `#38BDF8`, `#10B981`).
- **Glassmorphism**: Subtle translucent borders, backdrop blur (`backdrop-filter: blur(12px)`), and semi-transparent cards (`rgba(255, 255, 255, 0.05)`).
- **Crisp Typography**: Use clean font stacks (`Inter`, `Plus Jakarta Sans`, `system-ui`) with clear hierarchy (large bold headings, subtle muted subtitles).
- **Micro-Animations**: Smooth hover transitions (`transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1)`), button scale on click (`transform: scale(0.98)`), and subtle loading skeletons.

---

## 2. Layout & Responsiveness
- Use modern **Flexbox** and **CSS Grid** (`gap`, `auto-fit`, `minmax`).
- Design mobile-first or fully responsive layouts across mobile, tablet, and desktop breakpoints.
- Ensure all interactive elements have visible focus and hover states with smooth transitions.
